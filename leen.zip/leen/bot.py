from os import getenv

class Config:
    API_ID = int(getenv('API_ID','23205290'))
    API_HASH = getenv('API_HASH','264c001e21d8145cb8d39e0d87a12891')
    BOT_TOKEN = getenv('BOT_TOKEN','5167943610:AAGc7xugCtSGtAP_8gmVBl0FQWxRJNRtgnI')

config = Config()
