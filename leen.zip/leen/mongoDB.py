from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi  #here you import the mongoDB libraries

#Here you must enter the URL data that your mongo account provided you in the connect section
#remember that you must replace <password> with the password of your database configured previously

uri = "mongodb+srv://wagih:<Mm20202029>@cluster0.psr8wq7.mongodb.net/?retryWrites=true&w=majority"

client = MongoClient(uri, server_api=ServerApi('1'))

database = client['users']
collection = database['users']
collection_dos = database['keys']
collection_tres = database['groups']
collection_cuatro = database['ban']
collection_cinco = database['bin_ban']

try:
    client.admin.command('ping')
    print("Ping successfully!")
except Exception as e:
    print(f'An error has occurred! {e}')
    
    