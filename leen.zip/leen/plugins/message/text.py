cmds_text = """<b>
▰ Gates Online! 

♔︎ | Charged    ᛏ 1
♔︎ | Auth   ᛏ 1
♔︎ | CCN    ᛏ 0
</b>"""