from pyrogram.types import *


cmds = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton( 
                            "Gates",
                            callback_data="gates"
                        ),
                        InlineKeyboardButton(
                            "Tools",
                            callback_data="tools"
                        ),
                    ],
                    [
                        InlineKeyboardButton( 
                            "Perfil",
                            callback_data="you"),
                    ],
                ]
            )



