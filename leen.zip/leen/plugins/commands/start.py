from configs.datos import *
from pyrogram.types import *
photo = "plugins/commands/photo.jpg"


@abigail(['start','ini'])
async def start(_, message):
    await message.reply_chat_action(enums.ChatAction.TYPING)
    e = collection.find_one({"_id": message.from_user.id}) 
    if e is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
       
    user=message.from_user.first_name
    user_id=message.from_user.id
    caption = f"""<b>Hey!, <a href='tg://user?id={user_id}'><b>{user}</b></a>
welcome to !Leen if you are interested in knowing my commands press <code>!cmds</code></b>"""
            
    start=InlineKeyboardMarkup(
        [
            [
        
                InlineKeyboardButton("Channel", url="https://t.me/Add4G")
                
            ]
            
        ]

    )
     
    await Client.send_photo(_,photo=photo,chat_id=message.chat.id,caption=caption,reply_to_message_id=message.id,reply_markup=start)
            


