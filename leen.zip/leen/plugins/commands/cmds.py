from configs.datos import *

@abigail('cmds')
async def cmd(_, message):
    await message.reply_chat_action(enums.ChatAction.TYPING)
    c = collection.find_one({"_id": message.from_user.id})
    if c is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
    
    await message.reply(cmds_text, reply_markup=cmds,quote=True)
            

