from configs.datos import *
from datetime import datetime
from datetime import timedelta

photo = "plugins/commands/photo.jpg"

@abigail('claim')
async def claim(_,message):
	permission = collection.find_one({"_id": message.from_user.id})
	if permission is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
    
    
	ccs = message.text[len('/claim'):]
	space = ccs.split()
	if len(space)==0: return await message.reply('<b><code>!claim + key</code></b>',quote=True)
	key = space[0]

	key_ = collection_dos.find_one({"key": key})
	if key_ is None: return await message.reply(text='''<i>
Key Not Found! ❌</i>''',quote=True)

		
	days = key_['days']
	x = datetime.now() + timedelta(days=days)

	collection.update_one({"_id": message.from_user.id},{"$set": {"key": x}})
	collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 30}})
	collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Premium'}})
	collection_dos.delete_one({"key": key})

	caption = f'''<i>
━━━━━━━━━━━━━━━━━━━
Key Claimed! 🟩

𝖨𝖣: {message.from_user.username}
Range: <code>Premium</code>
𝖪𝖾𝗒: <code>{key}</code>
Expiration: <code>{x.strftime("%d %B %X")}</code>	
</i>'''

	await Client.send_photo(_, photo=photo,chat_id=message.chat.id,caption=caption,reply_to_message_id=message.id)
    



