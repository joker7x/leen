from configs.datos import *

@abigail('delete')
async def delete(_,message):
    
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code>></b>',quote=True)
    if buscar_permisos["role"] == "Owner" or buscar_permisos["role"] == "Co-Owner": pass
    	
    else: return await message.reply(text='<i>Permission denied for this command! ❌</i>',quote=True)
    ccs = message.text[len('/delete'):]
    space = ccs.split()
    
    if len(space)==0: return await message.reply('<code>!delete + key</code>',quote=True)
    key = space[0]
    encontrar_key = collection_dos.find_one({"key": key})
    if encontrar_key is None: return await message.reply(text='''<i>
key does not exist! ❌</i>''',quote=True)
		
    collection_dos.delete_one({"key": key})
    texto = f'''<i>
key deleted successfully
</i>'''
    await message.reply(texto,quote=True)