from configs.datos import *
from datetime import datetime

photo = "plugins/commands/photo.jpg"

@abigail('gkey')
async def gkey(_,message):
   
    
	permi = collection.find_one({"_id": message.from_user.id})
	if permi is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
        
    
	if permi["role"] == "Owner" or permi["role"] == "Co-Owner": pass	
	else: return await message.reply(text='<i>Permission denied for this command! ❌</i>',quote=True)
	ccs = message.text[len('/gkey'):]
	space = ccs.split()
	if len(space)==0: return await message.reply('<i><code>$gkey + days</code></i>',quote=True)
		
	days = space[0]

	key = f'Key-{str(random.randint(1000, 9999))}-Abigail-{str(random.randint(1000, 9999))}-{str(random.randint(1000, 9999))}-{days}'
	my_dict = {
	"key" : key,
	"days" : int(days)
	}
	collection_dos.insert_one(my_dict)
	caption = f'''<i>
━━━━━━━━━━━━━━━━━━━
Key generated successfully
𝖪𝖾𝗒: <code>{key}</code>
𝖯𝗅𝖺𝗇: <code>Full Plus</code>
Dias: <code>{days} days</code>
To claim use: <code>!claim {key}</code>
━━━━━━━━━━━━━━━━━━━
𝗀𝖾𝗇𝖾𝗋𝖺𝗍𝖾𝖽 : @{message.from_user.username} | {permi['role']}
</i>'''

    
	await Client.send_photo(_, photo=photo,chat_id=message.chat.id,caption=caption,reply_to_message_id=message.id,)