from configs.datos import *
from datetime import datetime

photo = "plugins/commands/photo.jpg"

@abigail('addchat')
async def addgp(_,message):

	permission = collection.find_one({"_id": message.from_user.id})
	if permission is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
 	
	if permission["role"] == "Owner" or permission["role"] == "Co-Owner": pass
	else: return await message.reply('<i>Permission denied for this command! ❌</i>')
		
	ccs = message.text[len('/addchat'):]
	espacios = ccs.split()
	if len(espacios)==0:
		return await message.reply('<b> <code>/addchat +  days</code></b>',quote=True)

	days = espacios[0]

	x = datetime.now() + timedelta(days=int(days))

	key = collection_tres.find_one({"group": str(message.chat.id)})
	if key is None:
		my_dict = {
		"group" : str(message.chat.id),
		"days" : int(days),
		"key" : x,
		}
		collection_tres.insert_one(my_dict)
		caption = f"""<i>
The group {message.chat.id} has been active for {days} days
━━━━━━━━━━━━━━━━━━━
</i>"""
		await Client.send_photo(_, photo=photo,chat_id=message.chat.id,caption=caption,reply_to_message_id=message.id)

	else:
		texto = f'<i>This group already has premium membership!</i>'
		await message.reply(texto,quote=True)