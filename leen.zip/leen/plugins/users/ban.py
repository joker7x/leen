from configs.datos import *

@abigail('gban')
async def ban(_,message):
    permission = collection.find_one({"_id": message.from_user.id})
    if permission is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
 	
    if permission["role"] == "Owner" or permission["role"] == "Co-Owner": pass
    else: return await message.reply('<i>Permission denied for this command! ❌</i>')
    try:  
        if message.reply_to_message.from_user.id:
            user = collection.find_one({"_id": message.reply_to_message.from_user.id})
    except: return await message.reply('<i>Reply to a text to add to the ban database!</b>')
    
    
    search= collection.find_one({"_id": user})
    if search is None: return await message.reply('<b>User Not Found</b>',quote=True)
    
    collection.update_one({"_id": user},{"$set": {"role": 'ban'}})
    collection.update_one({"_id": user},{"$set": {"key": 'None'}})
    collection.update_one({"_id": user},{"$set": {"plan": 'Ban'}})
    
    texto = f'''<i>
The user has been banned!
</i>'''

    await message.reply(texto,quote=True)