from configs.datos import *
from datetime import datetime


@abigail('register')
async def register(_,message):
    await message.reply_chat_action(enums.ChatAction.TYPING)
    
    try:
        find = collection.find_one({"_id": message.from_user.id})
        if find is None:
                            
            mydict = {
            "_id": message.from_user.id,
            "id": message.from_user.id,
            "username": message.from_user.username,
            "plan": "Free User",
            "role": "User",
            "credits": 0,
            "antispam": 50,
            "time_user": 0,
            "alerts": 0,
            "since": datetime.now(),
            "key" : 'None',


            }
            collection.insert_one(mydict)
            text = f'''<i>
Hello, your registration was successful
</i>'''
            await message.reply(text=text,quote=True)
        else:
            await message.reply(text='<i>You are already registered!</i>',quote=True)
    except Exception as e:
        await message.reply(f"And error ocurred! {e}",quote=True)