from configs.datos import *

photo = "plugins/comandos/photo.jpg"

@abigail('vip')
async def gkey(_,message):
   
  buscar_permisos = collection.find_one({"_id": message.from_user.id})
  if buscar_permisos is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
        
    
  if buscar_permisos["role"] == "Owner" or buscar_permisos["role"] == "Co-Owner": pass	
  else: return await message.reply(text='<i>Permission denied for this command! ❌</i>',quote=True)
  user = collection.find_one({"_id": message.reply_to_message.from_user.id})
  if user is None: return await message.reply('<i>User Not Found!</b>',quote=True)
    
  ccs = message.text[len('/vip'):]
  space = ccs.split()
  if len(space)==0: return await message.reply('<i><code>$vip + days</code></i>',quote=True)
  days = space[0]
  x = datetime.now() + timedelta(days=days)

  collection.update_one({"_id": user},{"$set": {"key": x}})
  collection.update_one({"_id": user},{"$set": {"antispam": 30}})
  collection.update_one({"_id": user},{"$set": {"plan": 'Premium'}})
  caption = f'''<i>
user added to premium with {days} days of access
</i>'''

    
  await Client.send_photo(_, photo=photo,chat_id=message.chat.id,caption=caption,reply_to_message_id=message.id,)