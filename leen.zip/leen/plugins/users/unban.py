from configs.datos import *
from datetime import datetime

@abigail('ungban')
async def ban(_,message):
    permission = collection.find_one({"_id": message.from_user.id})
    if permission is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
 	
    if permission["role"] == "Owner" or permission["role"] == "Co-Owner": pass
    else: return await message.reply('<i>Permission denied for this command! ❌</i>')
    try:  
        if message.reply_to_message.from_user.id:
            user = collection.find_one({"_id": message.reply_to_message.from_user.id})
    except: return await message.reply('<i>Reply to a text to remove from the ban base!</b>')
    
    
    search = collection.find_one({"_id": user})
    if search is None: return await message.reply('<b>User Not Found!</b>',quote=True)
    
    collection.update_one({"_id": user},{"$set": {"role": 'user'}})
    collection.update_one({"_id": user},{"$set": {"key": 'None'}})
    collection.update_one({"_id": user},{"$set": {"plan": 'Free User'}})
    
    texto = f'''<i>
he user has been unbanned!
</i>'''

    await message.reply(texto,quote=True)