from configs.datos import *
from datetime import datetime

photo = "plugins/commands/photo.jpg"

@abigail('add')
async def gkey(_,message):
   
  permission = collection.find_one({"_id": message.from_user.id})
  if permission is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
        
    
  if permission["role"] == "Owner" or permission["role"] == "Co-Owner": pass	
  else: return await message.reply(text='<i>Permission denied for this command! ❌</i>',quote=True)
  user = collection.find_one({"_id": message.reply_to_message.from_user.id})
  if user is None: return await message.reply('<i>user not found!</b>')
  x = datetime.now() + timedelta(days=30)

  collection.update_one({"_id": user},{"$set": {"key": x}})
  collection.update_one({"_id": user},{"$set": {"antispam": 2}})
  collection.update_one({"_id": user},{"$set": {"plan": 'Seller'}})
  collection.update_one({"_id": user},{"$set": {"role": 'Co-Owner'}})
  caption = f'''<i>
Hello, the promotion to seller was successful
</i>'''

    
  await Client.send_photo(_, photo=photo,chat_id=message.chat.id,caption=caption,reply_to_message_id=message.id,)