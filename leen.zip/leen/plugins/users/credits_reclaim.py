from configs.datos import *
from datetime import datetime
from datetime import timedelta

photo = "plugins/commands/photo.jpg"

@abigail('reclaim')
async def claim(_,message):
	buscar_permisos = collection.find_one({"_id": message.from_user.id})
	if buscar_permisos is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)

	ccs = message.text[len('/reclaim'):]
	space = ccs.split()
	if len(space)==0: return await message.reply('<code>/reclaim + key </code>',quote=True)
	key = space[0]

	encontrar_key = collection_dos.find_one({"key": key})
	if encontrar_key is None: return await message.reply(text='''<i>
Key Not Found! ❌</i>''',quote=True)
		
	days = encontrar_key['credit']
	x = days

	collection.update_one({"_id": message.from_user.id},{"$set": {"credits": x}})
	collection_dos.delete_one({"key": key})

	caption = f'''<i>
━━━━━━━━━━━━━━━━━━━
Key Claimed! 🟩

𝖨𝖣: {message.from_user.username}
𝖪𝖾𝗒: <code>{key}</code>
Credits: <code>{x}</code>	
</i>'''

	await Client.send_photo(_, photo=photo,chat_id=message.chat.id,caption=caption,reply_to_message_id=message.id)