from configs.datos import *

video = "plugins/commands/photo.jpg"

@abigail('credits')
async def gkey(_,message):
    
	permission = collection.find_one({"_id": message.from_user.id})
	if permission is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
        
    
	if permission["role"] == "Owner" or permission["role"] == "Co-Owner": pass	
	else: return await message.reply(text='<i>Permission denied for this command! ❌</i>',quote=True)
		
	ccs = message.text[len('/credits'):]
	space = ccs.split()
	if len(space)==0: return await message.reply('<b> <code>!credits + Number credits</code></b>',quote=True)
		
	credits = space[0]

	key = f'Key-{str(random.randint(1000, 9999))}-Abigail-{credits}'
	my_dict = {
	"key" : key,
	"credit" : int(credits)
	}
	collection_dos.insert_one(my_dict)
 
	caption = f'''<b>
━━━━━━━━━━━━━━━━━━━
Key generated successful

𝖪𝖾𝗒: <code>{key}</code>
Credits: <code>{credits}</code>
To claim use: <code>/reclaim {key}</code>
━━━━━━━━━━━━━━━━━━━
𝗀𝖾𝗇𝖾𝗋𝖺𝗍𝖾𝖽 𝖻𝗒: @{message.from_user.username} | {permission['role']}
</b>'''

    
	await Client.send_photo(_, video=video,chat_id=message.chat.id,caption=caption,reply_to_message_id=message.id)
