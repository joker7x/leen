from configs.datos import *
from pyrogram.types import *

@Client.on_callback_query(filters.regex("home"))
async def home(client, callback_query):
    
    texto= """<b>
▰ Gates Online | 

♔︎ | Charged    ᛏ 1
♔︎ | Auth   ᛏ 1
♔︎ | CCN    ᛏ 0
</b>"""
    reply_markup = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton( 
                            "Gates",
                            callback_data="gates"
                        ),
                        InlineKeyboardButton(
                            "Tools",
                            callback_data="tools"
                        ),
                    ],
                    [
                        InlineKeyboardButton( 
                            "Perfil",
                            callback_data="perfil"),
                    ],
                ]
            )
    await callback_query.edit_message_text(
        texto,
        reply_markup=reply_markup
    )

