from configs.datos import *
from pyrogram.types import *

@Client.on_callback_query(filters.regex("gates"))
async def gates(client, message):
    
    
    texto= """<b>
▰ Gates Online | 

♔︎ | Charged    ᛏ 1
♔︎ | Auth   ᛏ 1
♔︎ | CCN    ᛏ 1
</b>"""

    reply_markup = InlineKeyboardMarkup( 
                [
                    [
                        InlineKeyboardButton( 
                            "Charged",
                            callback_data="cargos"
                        ),
                        InlineKeyboardButton(
                            "Auth",
                            callback_data="auth"
                        ),
                    ],
                    [
                        InlineKeyboardButton( 
                            "CCN",
                            callback_data="ccn"),
                         ],
                    [
                      InlineKeyboardButton(
                    "Exit!",
                    callback_data="exit"
                ),
                    
               ],
            ]
         )

    await message.edit_message_text(texto, reply_markup=reply_markup)