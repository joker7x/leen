from configs.datos import *
from datetime import datetime
from pyrogram.types import *

@Client.on_callback_query(filters.regex("you"))
async def gates(client, msg):
    
    a = collection.find_one({"_id": msg.message.reply_to_message.from_user.id})
    credits = a["credits"]
    if credits != 0:
        credits = a["credits"]
    else:
        credits = 'None'
    
    id_usuo = a["id"]
    user_name = a["username"]
    plan = a["plan"]
    key_ = a["key"]
    if key_ != 'None':
        key_ = key_.strftime('%d %B %X')
    else:
        key_ = 'None.'
        
    caption = f"""<i>      
━━━━━━━━━━━━━━━━━━━
Info :

ID  <code>{id_usuo}</code>
Username <code>{user_name}</code>
Plan  <code>{plan}</code>
Credits  <code>{credits}</code>
Key  <code>{key_}</code>
━━━━━━━━━━━━━━━━━━━
</i>"""
    reply_markup = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "Back",
                    callback_data="home"
                ),
                InlineKeyboardButton(
                    "Exit!",
                    callback_data="exit"
                ),
        ]
        ]
    )



    await msg.edit_message_text(caption, reply_markup=reply_markup)