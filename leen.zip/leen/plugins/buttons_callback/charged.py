from configs.datos import *
from pyrogram.types import *

@Client.on_callback_query(filters.regex("cargos"))
async def tools(client, message):

   caption = """<b>
[Premium-Plan] <code>!br cc|mm|yy|cvv</code> ✅
ᚠ|Tipo  Charge
ᛈ|Nombre Stripe
ᚻ|Comentarios GATE OFFLINE

[Premium-Plan] <code>!chk cc|mm|yy|cvv</code> ✅
ᚠ|Tipo  B3  
ᛈ|Nombre Braintree
ᚻ|Comentarios GATE ONLINE
</b>"""

   reply_markup = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "Back",
                    callback_data="home"
                ),
                InlineKeyboardButton(
                    "Exit!",
                    callback_data="exit"
                ),
        ]
        ]
    )


   await message.edit_message_text(caption, reply_markup=reply_markup)