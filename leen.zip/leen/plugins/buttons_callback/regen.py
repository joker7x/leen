from configs.datos import *
from pyrogram.types import *

@Client.on_callback_query(filters.regex("gen_pro"))
async def regen(client, msg): 
    tiem= time.perf_counter()  
    men = msg.message.reply_to_message.text
    geneoa= men.split()[1]
    
    geneo = re.findall(r'[0-9]+',geneoa)
    if len(geneo) == 1:
        cc = geneo[0]
        mes = 'x'
        ano = 'x'
        cvv = 'x'
    elif len(geneo) ==2:
        cc = geneo[0]
        mes = geneo[1]
        ano = 'x'
        cvv = 'x'
    elif len(geneo) ==3:
        cc = geneo[0]
        mes = geneo[1]
        ano = geneo[2]
        cvv = 'x'
    elif len(geneo) ==4:
        cc = geneo[0]
        mes = geneo[1]
        ano = geneo[2]
        cvv = geneo[3]
    else:
        cc = geneo[0]
        mes = geneo[1]
        ano = geneo[2]
        cvv = geneo[3]

    cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10 = cc_gen(cc,mes,ano,cvv)
    
    user=msg.from_user.username
    
    extra = str(cc) + 'xxxxxxxxxxxxxxxxxxxxxxx'
    if mes == 'x':
        mes_2 = 'rnd'
    else:
        mes_2 = mes
    if ano == 'x':
        ano_2 = 'rnd'
    else:
        ano_2 = ano
    if cvv == 'x':
        cvv_2 = 'rnd'
    else:
        cvv_2 = cvv


    cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10, = cc_gen(cc,mes,ano,cvv)
    
    
    x = get_bin_info(geneoa[0:6])
            

    v = collection.find_one({"_id": msg.message.reply_to_message.from_user.id})
    
    reply_markup = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton( 
                            "Re Gen🔄",
                            callback_data="gen_pro"
                        ),
                    
                    ],
                ]
            )
    stop = time.perf_counter()
    tim = str(tiem - stop)[1:5]

    gen = f"""<b>
Card generator CC's
━━━━━━━━━━━━
Input: <code>{extra[0:16]}|{mes_2}|{ano_2}|{cvv_2}</code>.
━━━━━━━━━━
<code>{cc1}</code>
<code>{cc2}</code>  
<code>{cc3}</code>
<code>{cc4}</code> 
<code>{cc5}</code>
<code>{cc6}</code>
<code>{cc7}</code>
<code>{cc8}</code>
<code>{cc9}</code>
<code>{cc10}</code>
━━━━━━━━━━ 
Bin: <code>{cc[0:6]}</code>
Data: <code>{x.get("vendor")} - {x.get("type")} - {x.get("level")}</code>
Bank: <code>{x.get("bank_name")} </code>
Country: <code>{x.get("country")} {x.get("flag")}</code>
━━━━━━━━━━━━━━━━━━━━━━
Time: <code>{tim}</code>
Gen By: @{user} | [{v['plan']}]
</b>"""



    await msg.edit_message_text(gen,reply_markup=reply_markup)

