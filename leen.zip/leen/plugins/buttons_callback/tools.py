from configs.datos import *
from pyrogram.types import *

@Client.on_callback_query(filters.regex("tools"))
async def tools(client, message):
    
    Tools = """<b>

▰  Tools

⁂| Command <code>$bin</code>
⁂| Ej <code>$bin 434769</code>

⁂| Command <code>$gen</code>
⁂| Ej <code>$gen 434769|rnd|rnd|rnd</code>

⁂| Command <code>$rand</code>
⁂| Ej <code>$rand mx</code>

⁂| Command <code>$extra</code>
⁂| Ej <code>$extra 434769|rnd|rnd|rnd</code>

⁂| Command <code>$yt</code>
⁂| Ej <code>$yt + link youtube</code>
</b>"""

    reply_markup = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "Back",
                    callback_data="home"
                ),
                InlineKeyboardButton(
                    "Exit!",
                    callback_data="exit"
                ),
        ]
        ]
    )
    await message.edit_message_text(Tools, reply_markup=reply_markup)