from configs.datos import *
from datetime import datetime

@abigail('rand')
async def cmds(client, msg):
    await msg.reply_chat_action(enums.ChatAction.TYPING)
    v = collection.find_one({"_id": msg.from_user.id})
    if v is None: return await msg.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
    
    if v["role"] == "ban":
        return await msg.reply('<i>User from banned Bot!</i>',quote=True)
    
    po = collection_tres.find_one({"group": str(msg.chat.id)})

    if v['key'] != 'None' or po != None:
        if v['key'] != 'None':
            if v["key"] < datetime.now():            
                collection.update_one({"_id": msg.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": msg.from_user.id},{"$set": {"antispam": 50}})
                collection.update_one({"_id": msg.from_user.id},{"$set": {"plan": 'Free'}})
                return await msg.reply(text='<b>Key Expired! ❌</b>',quote=True)
        elif po["key"] < datetime.now():
            collection_tres.delete_one({"group": str(msg.chat.id)})

        else: return await msg.reply(text='<i>Hello, this group or chat is not authorized for the use of this bot.</i>',quote=True)
    zipcode = msg.text[len('/rand '):]
    if not zipcode:
               await msg.reply("<b><code>$rand ca</code></b>",quote=True)
               return
            
    api = requests.get(f"https://randomuser.me/api/?nat={zipcode}&inc=name,location").json()

    
    name = api["results"][0]["name"]["first"]
    last = api["results"][0]["name"]["last"]
    street = api["results"][0]["location"]["street"]["name"]
    nm = api["results"][0]["location"]["street"]["number"]
    city = api["results"][0]["location"]["city"]
    state = api["results"][0]["location"]["state"]
    country = api["results"][0]["location"]["country"]
    postcode = api["results"][0]["location"]["postcode"]
            
    await msg.reply(f"""<b> 
Generator Random Address
━━━━━━━━━━━━
Name: <code>{name} {last}</code>
Street: <code> {street} {nm}</code>
City: <code>{city}</code>
State: <code>{state}</code>
PostCode: <code>{postcode}</code>
Country: <code>{country}</code>
━━━━━━━━━━━━
Gen By: <code>@{msg.from_user.username}</code> | [{v['plan']}]
 </b>""",quote=True)
        