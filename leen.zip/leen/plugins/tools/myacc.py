from configs.datos import *
from pyrogram.types import *
from datetime import datetime


@abigail('myacc')
async def me(_,message):
    await message.reply_chat_action(enums.ChatAction.TYPING)
    
    try:  
        if message.reply_to_message.from_user.id:
            a = collection.find_one({"_id": message.reply_to_message.from_user.id})
    except: a = collection.find_one({"_id": message.from_user.id})
    
    if a is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></</b>',quote=True)
    
    credits = a["credits"]
    if credits != 0:
        credits = a["credits"]
    else:
        credits = 'None'
    
    id_usuo = a["id"]
    user_name = a["username"]
    plan = a["plan"]
    key_ = a["key"]
    if key_ != 'None':
        key_ = key_.strftime('%d %B %X')
    else:
        key_ = 'None.'
        
    caption = f"""<i>      
━━━━━━━━━━━━━━━━━━━
Info :

ID  <code>{id_usuo}</code>
Username <code>{user_name}</code>
Plan  <code>{plan}</code>
Credits  <code>{credits}</code>
Key  <code>{key_}</code>
━━━━━━━━━━━━━━━━━━━
</i>"""
    reply_markup = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "Back",
                    callback_data="home"
                ),
                InlineKeyboardButton(
                    "Exit!",
                    callback_data="exit"
                ),
        ]
        ]
    )


    await message.reply(caption,reply_markup=reply_markup,quote=True)

        