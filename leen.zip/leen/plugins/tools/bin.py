from configs.datos import *
from datetime import datetime

@abigail('bin')
async def cmds(client, msg):
    await msg.reply_chat_action(enums.ChatAction.TYPING)
    v = collection.find_one({"_id": msg.from_user.id})
    if v is None: return await msg.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
    
    if v["role"] == "ban":
        return await msg.reply('<i>User from banned Bot!</i>',quote=True)
    
    po = collection_tres.find_one({"group": str(msg.chat.id)})

    if v['key'] != 'None' or po != None:
        if v['key'] != 'None':
            if v["key"] < datetime.now():            
                collection.update_one({"_id": msg.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": msg.from_user.id},{"$set": {"antispam": 50}})
                collection.update_one({"_id": msg.from_user.id},{"$set": {"plan": 'Free'}})
                return await msg.reply(text='<b>Key Expired! ❌</b>',quote=True)
        elif po["key"] < datetime.now():
            collection_tres.delete_one({"group": str(msg.chat.id)})

        else: return await msg.reply(text='<i>Hello, this group or chat is not authorized for the use of this bot.</i>',quote=True)
    BIN = msg.text[len("/bin"): 11]

    if len(BIN) < 6:
            return await msg.reply("<b><code>!bin 434769xxxxx|rnd|rnd|rnd</code></b>",quote=True)
    if not BIN:
            return await msg.reply("<b>>code>!bin 434769xxxxx|rnd|rnd|rnd</code></b>",quote=True)
    inputm = msg.text.split(None, 1)[1]
    bincode = 6
    BIN = inputm[:bincode]
    x = get_bin_info(BIN[0:6])
                

    await msg.reply(f"""<i>
Bin: <code>{BIN[0:6]}</code> 
━━━━━ Bin Info ━━━━━                        
Data: <code>{x.get("vendor")} - {x.get("type")} - {x.get("level")}</code>
Bank: <code>{x.get("bank_name")} </code>
Country: <code>{x.get("country")} {x.get("flag")}</code>
</i>""",quote=True)
    