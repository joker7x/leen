from configs.datos import *
from datetime import datetime

@abigail('extra')
async def generate_extra(client, message):
    start = time.perf_counter()
    v = collection.find_one({"_id": message.from_user.id})
    if v is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
    
    if v["role"] == "ban":
        return await message.reply('<i>User from banned Bot!</i>',quote=True)
    
    po = collection_tres.find_one({"group": str(message.chat.id)})

    if v['key'] != 'None' or po != None:
        if v['key'] != 'None':
            if v["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 50}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>Key Expired! ❌</b>',quote=True)
        elif po["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

        else: return await message.reply(text='<i>Hello, this group or chat is not authorized for the use of this bot.</i>',quote=True)
    
    BIN = message.text[len("/bin "): 11]


    inputm = message.text.split(None, 1)
    if len(inputm) != 2 or not inputm[1]:
        message_text = "<b><code>!extra 551507xxxxx|rnd|rnd|rnd</code></b>"
        await message.reply_text(
            text=message_text,
        )
        return

    BIN = inputm[1][:6]
    req = requests.get(f"https://bins.antipublic.cc/bins/{BIN}").json()

    try:
        brand = req['brand']
        country_name = req['country_name']
        country_flag = req['country_flag']
        bank = req['bank']
    except KeyError:
        message_text = "Error: Bin Not Found!"
        await message.reply_text(
            text=message_text
        )
        return

    
    extrapole_results = []
    for _ in range(30):
        random_digits = "".join(random.choice("0123456789") for _ in range(6))
        random_month = random.randint(1, 12)
        random_year = random.randint(2024, 2030)
        extrapole_results.append(f"<code>{BIN}{random_digits}xxxx|{random_month:02d}|{random_year}|rnd</code>")
        
    stop = time.perf_counter()
    x = get_bin_info(BIN[0:6])
    tim = str(start - stop)[1:5]

    message_text = f"""Extras Generator
━━━━━━━━━━━━━━━━━━━
""" + "\n".join(extrapole_results) + f"""<b>
━━━━━━━━━━━━━━━━━━━
Bin: <code>{BIN[0:6]}</code>
Data: <code>{x.get("vendor")} - {x.get("type")} - {x.get("level")}</code>
Bank: <code>{x.get("bank_name")} </code>
Country: <code>{x.get("country")} {x.get("flag")}</code>
━━━━━━━━━━━━━━━━━━━
Gen By: <code>@{message.from_user.username}</code> | [{v['plan']}]
Time: <code>{tim}</code>
</b>"""

    await message.reply(
        text=message_text,quote=True)