from configs.datos import *
from datetime import datetime
from configs.luhn import *
from pyrogram.types import *
import time
from datetime import datetime



@abigail('gen')
async def genccs(_, msg):
    tim = time.perf_counter()  
    await msg.reply_chat_action(enums.ChatAction.TYPING)
    v = collection.find_one({"_id": msg.from_user.id})
    if v is None: return await msg.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
    
    if v["role"] == "ban":
        return await msg.reply('<i>User from banned Bot!</i>',quote=True)
    
    bin_pro=['1','2','7','8','9']
    
    
    po = collection_tres.find_one({"group": str(msg.chat.id)})

    if v['key'] != 'None' or po != None:
        if v['key'] != 'None':
            if v["key"] < datetime.now():            
                collection.update_one({"_id": msg.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": msg.from_user.id},{"$set": {"antispam": 50}})
                collection.update_one({"_id": msg.from_user.id},{"$set": {"plan": 'Free'}})
                return await msg.reply(text='<b>Key Expired! ❌</b>',quote=True)
        elif po["key"] < datetime.now():
            collection_tres.delete_one({"group": str(msg.chat.id)})

        else: return await msg.reply(text='<i>Hello, this group or chat is not authorized for the use of this bot.</i>',quote=True)
        user = msg.from_user.username
        
    
        ccbin = msg.text[len('/gen '):]
        if not ccbin: return await msg.reply('<i>Invalid Bin!  ⚠️</i>',quote=True)
        if len(str(ccbin)) < 6: return await msg.reply('<i>Invalid Bin!  ⚠️</i>',quote=True)

        geneo = re.findall(r'[0-9]+',msg.text)
        if not geneo: return await msg.reply('<i>Invalid Bin! ⚠️</i>',quote=True)
        
        else:
            if len(geneo) == 1:
                cc = geneo[0]
                mes = 'x'
                ano = 'x'
                cvv = 'x'
            elif len(geneo) ==2:
                cc = geneo[0]
                mes = geneo[1]
                ano = 'x'
                cvv = 'x'
            elif len(geneo) ==3:
                cc = geneo[0]
                mes = geneo[1]
                ano = geneo[2]
                cvv = 'x'
            elif len(geneo) ==4:
                cc = geneo[0]
                mes = geneo[1]
                ano = geneo[2]
                cvv = geneo[3]
            else:
                cc = geneo[0]
                mes = geneo[1]
                ano = geneo[2]
                cvv = geneo[3]
            
            if cc[0] in bin_pro: return await msg.reply('<i>Invalid Bin! ⚠️</i>',quote=True)    
            x = get_bin_info(ccbin[0:6])
        

            cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10, = cc_gen(cc,mes,ano,cvv)
            
            extra = str(cc) + 'xxxxxxxxxxxxxxxxxxxxxxx'
            if mes == 'x':
             mes_2 = 'rnd'
            else:
             mes_2 = mes
            if ano == 'x':
             ano_2 = 'rnd'
            else:
             ano_2 = ano
            if cvv == 'x':
             cvv_2 = 'rnd'
            else:
             cvv_2 = cvv

            
            reply_markup = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton( 
                            "Re Gen🔄",
                            callback_data="gen_pro"
                        ),
                    
                    ],
                ]
            )
            
        stop = time.perf_counter()
        tim = str(tim - stop)[1:5]
    
        text = f"""<b>
Card generator CC's
━━━━━━━━━━━━
Input: <code>{extra[0:16]}|{mes_2}|{ano_2}|{cvv_2}</code>.
━━━━━━━━━━
<code>{cc1}</code>
<code>{cc2}</code>  
<code>{cc3}</code>
<code>{cc4}</code> 
<code>{cc5}</code>
<code>{cc6}</code>
<code>{cc7}</code>
<code>{cc8}</code>
<code>{cc9}</code>
<code>{cc10}</code>
━━━━━━━━━━ 
Bin: <code>{cc[0:6]}</code>
Data: <code>{x.get("vendor")} - {x.get("type")} - {x.get("level")}</code>
Bank: <code>{x.get("bank_name")} </code>
Country: <code>{x.get("country")} {x.get("flag")}</code>
━━━━━━━━━━━━━━━━━━━━━━
Time: <code>{tim}</code>
Gen By: @{user} | [{v['plan']}]
</b>"""
    
        return await Client.send_message(_,chat_id=msg.chat.id,text=text,reply_to_message_id=msg.id,reply_markup=reply_markup)