from configs.datos import *
from pytube import YouTube

@abigail('yt')
async def youtube_dl(client, message: Message):
    await message.reply_chat_action(enums.ChatAction.TYPING)
    
    e = collection.find_one({"_id": message.from_user.id})
    if e is None: return await message.reply(text='<b>hey!, you are not registered, use the command <code>!register</code></b>',quote=True)
    
    if e["role"] == "ban":
        return await message.reply('<b>User from banned Bot!</b>',quote=True)
    
    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if e['key'] != 'None' or encontrar_grupo != None:
        if e['key'] != 'None':
            if e["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 50}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>Key Expired! ❌</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

        else: return await message.reply(text='<i>Hello, this group or chat is not authorized for the use of this bot.</i>>',quote=True)
    hola = await message.reply('10/100 %')
    time.sleep(2)
    if len(message.command) == 1:
        await hola.edit("Link no existe")
        return
    
    youtube_link = message.text.split(None, 1)[1]
    await hola.edit('40/100 %')
    time.sleep(2)
    yt = YouTube(youtube_link)
    await hola.edit('50/100 %')
    video = yt.streams.get_highest_resolution()
    video.download()

    await hola.edit('60/100 %')
    time.sleep(2)
    await client.send_video(
        chat_id=message.chat.id,
        video=open(yt.title+'.mp4','rb'),
        caption=yt.title
    )
    os.remove(yt.title+'.mp4')