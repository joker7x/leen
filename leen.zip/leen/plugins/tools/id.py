from configs.datos import *

@abigail('id')
async def chat_id(_, m):
    await m.reply(f"""
<code>{m.chat.id}</code>""",quote=True)